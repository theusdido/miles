<?php
	// Credenciais
	$credenciais =  array(
		"email" => "theusdido@hotmail.com",
		"token" => "F0908AA5BC894935A8630A1153655E59"
	);