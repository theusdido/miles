<?php
    $retorno['data'] = tdc::da('td_website_geral_menuprincipal');