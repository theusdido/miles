<?php
$retorno["dados"] = tdc::da("td_ecommerce_categoria",tdc::f("inativo","=",0));