<?php
$retorno["dados"] = tdc::da("td_ecommerce_taxaentrega",tdc::f("inativo","=",0));