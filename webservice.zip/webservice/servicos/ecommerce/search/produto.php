<?php
$retorno["dados"] = tdc::da("td_ecommerce_produto",$criterio);